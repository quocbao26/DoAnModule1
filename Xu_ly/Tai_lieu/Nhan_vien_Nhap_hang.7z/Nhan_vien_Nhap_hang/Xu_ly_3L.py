from flask import   Markup, url_for
import json
import os
from datetime import datetime
Thu_muc_Du_lieu ="Du_lieu"
Thu_muc_Tivi = "Du_lieu/Tivi/"
Thu_muc_Cong_ty= "Du_lieu/Cong_ty/"

# Xử lý Thể hiện
def Tao_chuoi_HTML_Nhan_vien(Nhan_vien):
    Chuoi_HTML_Nhan_vien = '<div class="row" >'
    Chuoi_Hinh = '<img  style="width:60px;height:60px"  src="'+ \
                 url_for('static', filename = Nhan_vien["Ma_so"]+'.png') + '" />'
    Chuoi_Thong_tin = '<div class="btn" style="text-align:left"> Xin chào nhân viên Nhập hàng ' + \
                 Nhan_vien["Ho_ten"] + "</div>"
    
    Chuoi_HTML_Nhan_vien += Chuoi_Hinh + Chuoi_Thong_tin 
    
    return Markup(Chuoi_HTML_Nhan_vien)  

def Tao_Chuoi_HTML_Tivi(Tivi, Thong_bao, So_luong):
    Chuoi_Hinh='<img  style="width:300px" src="'+ \
                 url_for('static', filename = Tivi["Ma_so"]+'.png') + '" />'
    Chuoi_Loai_Tivi = "Thuộc loại: " + Tivi["Nhom_Tivi"]["Ten"] + "<br/>"
    Chuoi_Ky_hieu = "Ký hiệu:" + Tivi["Ky_hieu"] + "<br/>"
    Chuoi_SL_Ton = "Số lượng tồn:" + str(Tivi["So_luong_Ton"]) + "<br/>"
    Chuoi_Don_gia_Nhap="Đơn giá Nhập {:,}".format(Tivi["Don_gia_Nhap"]).replace(",",".") 
    Chuoi_Ngay = "Ngày: "  + datetime.now().strftime('%d-%m-%Y')
    Chuoi_HTML_Tivi = '''
        <div class="container">
          <div class="card" align="center">
            <h4 class="card-title">Phiếu nhập</h4>
            <h6 class="card-title">'''+ Chuoi_Ngay+'''</h6>
            ''' + Chuoi_Hinh + '''
            <div class="card-body">
              <h4 class="card-title">'''+ Tivi["Ten"]+'''</h4>
              <p class="card-text">'''+ Chuoi_Don_gia_Nhap +'''<br/>'''+ Chuoi_SL_Ton +''' </p>
    
              <form method="POST">
                <div class="container-fluid">
                  <div class="alert" style="height:30px">
                    <input name="Th_So_luong" type="number" required min="1" max="'''+ str(Tivi["So_luong_Ton"])+'''" spellcheck="false" 
                    autocomplete="off" value="'''+ str(So_luong) + '''"
                    />
                  </div>
                  <div class="alert" style="height:40px">
                    <button class="btn btn-danger" type="submit">Đồng ý</button>
                  </div>
                </div>
                <div>'''+ Thong_bao +'''</div>
              </form>
            </div>
          </div>
        </div>
        '''
    return Markup(Chuoi_HTML_Tivi)    

def Tao_Chuoi_HTML_Danh_sach_Tivi(Danh_sach_Tivi):   
    Chuoi_HTML_Danh_sach = '<div class="row" >'
    for Tivi in Danh_sach_Tivi:        
        Chuoi_Don_gia_Nhap="Đơn giá Nhập {:,}".format(Tivi["Don_gia_Nhap"]).replace(",",".")    
        Chuoi_So_luong_ton = "SL Tồn " + str(Tivi["So_luong_Ton"])
        Chuoi_Hinh='<img  style="width:60px;height:60px"  src="'+ \
                 url_for('static', filename = Tivi["Ma_so"]+'.png') + '" />'        
        Chuoi_Loai_Tivi = "Thuộc loại: " + Tivi["Nhom_Tivi"]["Ten"] + "<br/>"
        Chuoi_Ky_hieu = "Ký hiệu:" + Tivi["Ky_hieu"] + "<br/>"
        Chuoi_SL_Ton = "Số lượng tồn:" + str(Tivi["So_luong_Ton"]) + "<br/>"
        Chuoi_Thong_tin='<div class="btn" style="text-align:left">' + \
                 Tivi["Ten"] + "<br />" + Chuoi_Don_gia_Nhap + "<br/>" + \
                 Chuoi_SL_Ton + \
                 '''<a href="/Nhan_vien_Nhap_hang/Nhap/''' + Tivi["Ma_so"] +'''/">Nhập</a>'''+ '</div>'
        Chuoi_HTML ='<div class="col-md-4" >' +  \
                Chuoi_Hinh + Chuoi_Thong_tin + '</div>' 
        Chuoi_HTML_Danh_sach +=Chuoi_HTML 

    Chuoi_HTML_Danh_sach += '</div>'               
    return Markup(Chuoi_HTML_Danh_sach)  
 
def Tao_Chuoi_HTML_Thong_ke_Tivi(Danh_sach_Thong_ke):
    Ngay = "Ngày: " + datetime.now().strftime('%d-%m-%Y') 
    Chuoi_Tong_tien = "...Tổng tiền: {:,}".format(sum(Tivi['Tien'] for Tivi in Danh_sach_Thong_ke)).replace(",",".") 
    
    Chuoi_HTML_Danh_sach = '<div class="container"><h3>Thống kê Phiếu nhập</h3><br/><h5>' + Ngay + Chuoi_Tong_tien + '</h5></div>'
    Chuoi_HTML_Danh_sach += '<div class="row" >'
    
    stt = 1
    header = '''
        <div class="dong" >
        <div class="cot">STT</div>
        <div class="cot">Tivi</div>
        <div class="cot">Số lượng</div>
        <div class="cot">Đơn giá</div>
        <div class="cot">Tiền</div>
        </div>
        '''  
    Chuoi_HTML_Danh_sach +=header

    for Tivi in Danh_sach_Thong_ke:
        Chuoi_HTML = '''
        <div class="dong">
        <div class="cot">'''+ str(stt) +'''</div>
        <div class="cot">'''+ Tivi['Ten']+'''</div>
        <div class="cot">'''+ str(Tivi['So_luong']) +'''</div>
        <div class="cot">'''+ "{:,}".format(Tivi["Don_gia"]).replace(",",".") +'''</div>
        <div class="cot">'''+ "{:,}".format(Tivi["Tien"]).replace(",",".") +'''</div>
        </div>
        '''     
        stt += 1

        
        Chuoi_HTML_Danh_sach +=Chuoi_HTML 

    Chuoi_HTML_Danh_sach += '</div>'               
    return Markup(Chuoi_HTML_Danh_sach)  
